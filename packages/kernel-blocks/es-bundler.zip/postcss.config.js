/**
 * PostCSS configuration
 * This file is optional - the ESBuild setup includes default PostCSS plugins
 * Add this file if you need custom PostCSS configuration
 */

module.exports = {
    plugins: [
        require('postcss-preset-env')({
            stage: 0,
            features: {
                'custom-properties': false, // Use native CSS custom properties
                'nesting-rules': true,      // Enable CSS nesting
            },
        }),
        require('autoprefixer'),
        // Add more PostCSS plugins here as needed
        // require('postcss-custom-media'),
        // require('postcss-mixins'),
    ],
};
